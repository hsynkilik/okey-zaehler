/* Okey 101 solver: maximum meld sum, pairs hand.
   Tiles: {color:'red'|'yellow'|'blue'|'black', n:1..13} or {fake:true}.
   Indicator (Anzeigestein): {color, n}. The joker (Okey) is the same colour, n+1 (13 -> 1).
   Real Okey tiles are wildcards; the fake joker is an ordinary tile showing the Okey face. */
const COLORS = ['red', 'yellow', 'blue', 'black'];
const COLOR_INDEX = { red: 0, yellow: 1, blue: 2, black: 3 };
const cellIndex = (c, n) => c * 13 + (n - 1);

/* All possible melds, indexed by every cell they contain.
   Runs use positions 1..14 where position 14 is the 1 after the 13 (12-13-1 is allowed, 13-1-2 is not). */
const TEMPLATES_BY_CELL = (function () {
  const byCell = Array.from({ length: 52 }, () => []);
  const add = (cells, kind, vals) => {
    const t = { kind, cells, vals, points: vals.reduce((a, b) => a + b, 0) };
    for (const c of cells) byCell[c].push(t);
  };
  for (let c = 0; c < 4; c++) {
    for (let s = 1; s <= 12; s++) {
      for (let e = s + 2; e <= 14; e++) {
        if (e - s + 1 > 13) continue;
        const cells = [], vals = [];
        for (let p = s; p <= e; p++) {
          const n = p === 14 ? 1 : p;
          cells.push(cellIndex(c, n));
          vals.push(n);
        }
        add(cells, 'run', vals);
      }
    }
  }
  for (let n = 1; n <= 13; n++) {
    for (let mask = 0; mask < 16; mask++) {
      const cols = [];
      for (let c = 0; c < 4; c++) if (mask & (1 << c)) cols.push(c);
      if (cols.length < 3) continue;
      add(cols.map((c) => cellIndex(c, n)), 'group', cols.map(() => n));
    }
  }
  return byCell;
})();

function solveMelds(counts, jokers) {
  const state = counts.slice();
  const memo = new Map();
  const keyOf = (j) => {
    let k = String.fromCharCode(48 + j);
    for (let i = 0; i < 52; i++) k += String.fromCharCode(48 + state[i]);
    return k;
  };
  const firstCell = () => {
    for (let i = 0; i < 52; i++) if (state[i] > 0) return i;
    return -1;
  };
  function best(j) {
    const i = firstCell();
    if (i < 0) return 0;
    const k = keyOf(j);
    const hit = memo.get(k);
    if (hit) return hit.score;
    state[i]--;
    let bestScore = best(j);
    let choice = { skip: true };
    state[i]++;
    for (const t of TEMPLATES_BY_CELL[i]) {
      let need = 0;
      for (const c of t.cells) if (state[c] === 0) need++;
      if (need > j) continue;
      const missing = [];
      for (const c of t.cells) {
        if (state[c] > 0) state[c]--;
        else missing.push(c);
      }
      const sc = t.points + best(j - need);
      for (const c of t.cells) if (!missing.includes(c)) state[c]++;
      if (sc > bestScore) {
        bestScore = sc;
        choice = { tpl: t, missing };
      }
    }
    memo.set(k, { score: bestScore, choice });
    return bestScore;
  }
  const total = best(jokers);
  // rebuild the arrangement
  const melds = [];
  const leftover = [];
  let j = jokers;
  for (;;) {
    const i = firstCell();
    if (i < 0) break;
    const { choice } = memo.get(keyOf(j));
    if (choice.skip) {
      leftover.push({ color: COLORS[Math.floor(i / 13)], n: (i % 13) + 1 });
      state[i]--;
      continue;
    }
    const t = choice.tpl;
    const tiles = t.cells.map((c, idx) => {
      const isJoker = choice.missing.includes(c);
      if (!isJoker) state[c]--;
      return { color: COLORS[Math.floor(c / 13)], n: t.vals[idx], joker: isJoker };
    });
    j -= choice.missing.length;
    melds.push({ kind: t.kind, points: t.points, tiles });
  }
  return { total, melds, leftover, leftoverJokers: j };
}

function pairsHand(counts, jokers) {
  const pairs = [];
  const singles = [];
  counts.forEach((cnt, i) => {
    const tile = { color: COLORS[Math.floor(i / 13)], n: (i % 13) + 1 };
    for (let k = 0; k < Math.floor(cnt / 2); k++) pairs.push([tile, tile]);
    if (cnt % 2) singles.push(tile);
  });
  let j = jokers;
  while (j > 0 && singles.length) {
    pairs.push([singles.shift(), { joker: true }]);
    j--;
  }
  while (j >= 2) {
    pairs.push([{ joker: true }, { joker: true }]);
    j -= 2;
  }
  return { count: pairs.length, pairs, leftover: singles, leftoverJokers: j };
}

function analyse(tiles, indicator) {
  const counts = new Array(52).fill(0);
  let jokers = 0;
  let unresolvedFakes = 0;
  let okey = null;
  if (indicator) okey = { color: indicator.color, n: indicator.n === 13 ? 1 : indicator.n + 1 };
  for (const t of tiles) {
    if (t.fake) {
      if (okey) counts[cellIndex(COLOR_INDEX[okey.color], okey.n)]++;
      else unresolvedFakes++;
      continue;
    }
    if (okey && t.color === okey.color && t.n === okey.n) jokers++;
    else counts[cellIndex(COLOR_INDEX[t.color], t.n)]++;
  }
  const melds = solveMelds(counts, jokers);
  const pairs = pairsHand(counts, jokers);
  return { okey, jokers, unresolvedFakes, tileCount: tiles.length, ...melds, pairsHand: pairs };
}
