const fs = require('fs');
const d = __dirname;
const tpl = fs.readFileSync(d + '/app-template.html', 'utf8').split('\n');
const start = tpl.findIndex(l => l.includes('/* ---------- photo reading ---------- */'));
// final line of the script IIFE
let end = -1;
for (let i = tpl.length - 1; i >= 0; i--) { if (tpl[i] === '})();') { end = i; break; } }
if (start < 0 || end < 0) throw new Error('splice points not found');
const tail = fs.readFileSync(d + '/tail.js', 'utf8').replace(/\n$/, '').split('\n');
let out = tpl.slice(0, start).concat(tail, tpl.slice(end)).join('\n');
const solver = fs.readFileSync(d + '/solver.js', 'utf8');
if (!out.includes('/*SOLVER*/')) throw new Error('solver placeholder missing');
out = out.replace('/*SOLVER*/', () => solver);
fs.writeFileSync(d + '/index.html', out);
console.log('built', out.length, 'chars');
