const fs = require('fs');
const src = fs.readFileSync(__dirname + '/solver.js', 'utf8');
const { analyse, solveMelds, COLORS, COLOR_INDEX } = new Function(
  src + '; return {analyse, solveMelds, COLORS, COLOR_INDEX};'
)();

const T = (color, n) => ({ color, n });
let fail = 0;
const eq = (name, got, want) => {
  const ok = got === want;
  if (!ok) fail++;
  console.log((ok ? 'ok   ' : 'FAIL ') + name + ' -> ' + got + (ok ? '' : ' (want ' + want + ')'));
};

// hand-made cases
eq('run 1-2-3', analyse([T('red', 1), T('red', 2), T('red', 3)], null).total, 6);
eq('group of 4', analyse([T('red', 5), T('yellow', 5), T('blue', 5), T('black', 5)], null).total, 20);
eq('wrap 12-13-1', analyse([T('red', 12), T('red', 13), T('red', 1)], null).total, 26);
eq('13-1-2 invalid', analyse([T('red', 13), T('red', 1), T('red', 2)], null).total, 0);
// indicator blue 2 -> okey = blue 3 (wildcard)
eq('joker extends 4-5 to 4-5-6', analyse([T('red', 4), T('red', 5), T('blue', 3)], { color: 'blue', n: 2 }).total, 15);
eq('joker 12-13 -> 11-12-13', analyse([T('red', 12), T('red', 13), T('blue', 3)], { color: 'blue', n: 2 }).total, 36);
// indicator blue 13 -> okey = blue 1
eq('indicator 13 -> okey 1', analyse([T('red', 7), T('red', 8), T('blue', 1)], { color: 'blue', n: 13 }).total, 24);
// fake joker is a normal blue 3 when indicator is blue 2: blue 3 + blue 4 + blue 5
eq('fake = okey face', analyse([{ fake: true }, T('blue', 4), T('blue', 5)], { color: 'blue', n: 2 }).total, 12);
// pairs
const p = analyse([T('red', 4), T('red', 4), T('blue', 9), T('blue', 9), T('black', 1), T('black', 1), T('red', 2), T('yellow', 3), T('yellow', 8)], null);
eq('pairs', p.pairsHand.count, 3);
const pj = analyse([T('red', 4), T('red', 4), T('blue', 9), T('blue', 3)], { color: 'blue', n: 2 });
eq('pairs with joker', pj.pairsHand.count, 2);

// ---- independent brute force for small hands ----
function brutePoints(real, j) {
  // best points of ONE valid meld made of real tiles + j jokers, or -1
  const size = real.length + j;
  if (size < 3 || real.length === 0) return -1;
  let best = -1;
  // group
  if (size <= 4) {
    const n0 = real[0].n;
    const colors = new Set(real.map((t) => t.color));
    if (real.every((t) => t.n === n0) && colors.size === real.length) best = Math.max(best, n0 * size);
  }
  // run
  const c0 = real[0].color;
  if (real.every((t) => t.color === c0) && size <= 13) {
    for (let s = 1; s + size - 1 <= 14; s++) {
      const e = s + size - 1;
      // each real tile must sit on a distinct position in s..e
      const used = new Set();
      let ok = true;
      for (const t of real) {
        let pos = null;
        if (t.n >= s && t.n <= e) pos = t.n;
        if (t.n === 1 && e === 14 && s >= 2) pos = 14;
        if (pos === null || used.has(pos)) { ok = false; break; }
        used.add(pos);
      }
      if (ok) {
        let pts = 0;
        for (let q = s; q <= e; q++) pts += q === 14 ? 1 : q;
        best = Math.max(best, pts);
      }
    }
  }
  return best;
}
function brute(real, j) {
  const n = real.length;
  const full = (1 << n) - 1;
  const memo = new Map();
  // choose how many jokers each meld gets: recurse over (mask, j)
  function rec(mask, jk) {
    if (mask === 0) return 0;
    const k = mask * 8 + jk;
    if (memo.has(k)) return memo.get(k);
    const low = mask & -mask;
    const rest = mask ^ low;
    // low tile unused
    let best = rec(rest, jk);
    // low tile in a meld with a submask of rest and 0..jk jokers
    let sub = rest;
    for (;;) {
      const tiles = [];
      for (let b = 0; b < n; b++) if ((low | sub) & (1 << b)) tiles.push(real[b]);
      for (let u = 0; u <= jk; u++) {
        const pts = brutePoints(tiles, u);
        if (pts >= 0) best = Math.max(best, pts + rec(rest ^ sub, jk - u));
      }
      if (sub === 0) break;
      sub = (sub - 1) & rest;
    }
    memo.set(k, best);
    return best;
  }
  return rec(full, j);
}

let seed = 12345;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
let mism = 0;
const N = 400;
for (let it = 0; it < N; it++) {
  const nt = 6 + Math.floor(rnd() * 7); // 6..12 real tiles
  const jk = Math.floor(rnd() * 3);
  const pool = [];
  const colorsUsed = 2 + Math.floor(rnd() * 3);
  const lo = 1 + Math.floor(rnd() * 8);
  const real = [];
  while (real.length < nt) {
    const c = COLORS[Math.floor(rnd() * colorsUsed)];
    const nn = rnd() < 0.15 ? (rnd() < 0.5 ? 1 : 13) : lo + Math.floor(rnd() * 6);
    const t = { color: c, n: Math.min(13, nn) };
    if (real.filter((r) => r.color === t.color && r.n === t.n).length < 2) real.push(t);
  }
  // build counts directly, jokers separate
  const counts = new Array(52).fill(0);
  for (const t of real) counts[COLOR_INDEX[t.color] * 13 + t.n - 1]++;
  const got = solveMelds(counts, jk).total;
  const want = brute(real, jk);
  if (got !== want) {
    mism++;
    if (mism <= 5) console.log('MISMATCH', JSON.stringify(real), 'jokers', jk, 'got', got, 'want', want);
  }
}
eq('random vs brute force (' + N + ' hands)', mism, 0);

// performance: 22 tiles from the full 106-tile set, 2 real jokers
function fullDeck() {
  const d = [];
  for (let k = 0; k < 2; k++) for (const c of COLORS) for (let n = 1; n <= 13; n++) d.push({ color: c, n });
  return d;
}
let worst = 0;
for (let it = 0; it < 60; it++) {
  const d = fullDeck();
  for (let i = d.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [d[i], d[j]] = [d[j], d[i]]; }
  const hand = d.slice(0, 22);
  const ind = d[30];
  const t0 = Date.now();
  analyse(hand, ind);
  worst = Math.max(worst, Date.now() - t0);
}
console.log('worst time over 60 random 22-tile hands: ' + worst + ' ms');
// adversarial: dense single-colour hand with two jokers
const dense = [];
for (let n = 1; n <= 13; n++) dense.push(T('red', n));
for (let n = 1; n <= 9; n++) dense.push(T('red', n));
const t0 = Date.now();
const dr = analyse(dense, { color: 'blue', n: 2 });
console.log('dense hand total ' + dr.total + ' in ' + (Date.now() - t0) + ' ms');
console.log(fail === 0 && mism === 0 ? 'ALL OK' : 'FAILURES: ' + fail);
