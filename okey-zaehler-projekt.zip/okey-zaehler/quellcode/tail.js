/* ---------- photo reading ---------- */
var PROMPT = [
  'You are reading a photo of a player\'s rack in the Turkish tile game Okey (101 Okey).',
  'Each tile shows a number from 1 to 13 in one of four colours: red, yellow (it may look orange or gold), blue or black.',
  'A fake okey tile shows a symbol (a star, clover or ornament) instead of a number. Report it as {"fake": true}.',
  '',
  'List every tile of the player\'s own hand, row by row, top row first, each row from left to right. Skip gaps between tiles.',
  'Ignore anything that is not a tile of the hand, such as tiles lying apart from the rack, the table or the background.',
  'Look closely at the digits and tell 1 and 7, 3 and 8, 6 and 9, 5 and 6, and blue and black apart carefully.',
  'Set "unsure": true on every tile where the number or colour is not clearly readable. Never skip a tile you can see: give your best guess and mark it unsure.',
  '',
  'Reply with only a JSON object of this shape:',
  '{"rows":[[{"color":"red","n":5,"unsure":false},{"fake":true,"unsure":false}],[{"color":"blue","n":12,"unsure":true}]],"note":"one short German sentence if the photo is hard to read, otherwise an empty string"}',
  'color is one of red, yellow, blue, black. n is an integer from 1 to 13. If no tiles are visible, return {"rows":[],"note":"a short German explanation"}.'
].join('\n');

function errorCopy(e) {
  var s = e && e.status;
  var m = (e && e.message) ? String(e.message) : '';
  if (e && e.code === 'invalid_json') return 'Claude hat keine lesbare Antwort geliefert. Mach ein schärferes Foto von oben, mit dem ganzen Ständer im Bild.';
  if (e && e.code === 'timeout') return 'Das Lesen hat zu lange gedauert. Tippe auf Neu lesen.';
  if (e && e.code === 'image') return 'Das Foto lässt sich nicht laden. Wähle ein JPEG oder PNG.';
  if (s === 401) return 'Der API-Schlüssel wird abgelehnt. Prüfe ihn in den Einstellungen.';
  if (s === 403) return 'Dieser Schlüssel hat dafür keine Berechtigung. Prüfe ihn in der Anthropic Console.';
  if (s === 404) return 'Modell nicht gefunden. Prüfe die Modellnamen unter Einstellungen, Erweitert.';
  if (s === 413) return 'Das Foto ist zu groß. Wähle ein kleineres Foto.';
  if (s === 400 && /credit|balance|billing/i.test(m)) return 'Dein Guthaben bei Anthropic ist aufgebraucht. Lade es in der Console auf.';
  if (s === 400) return 'Die Anfrage wurde abgelehnt (' + esc(m.slice(0, 160)) + ').';
  if (s === 429) return 'Zu viele Anfragen oder dein Limit ist erreicht. Warte kurz und tippe dann auf Neu lesen.';
  if (s >= 500) return 'Claude ist gerade überlastet. Tippe gleich auf Neu lesen.';
  return 'Keine Verbindung zu Anthropic. Prüfe dein Netz und tippe auf Neu lesen.';
}

function loadBitmap(file) {
  return (async function () {
    try {
      return await createImageBitmap(file, { imageOrientation: 'from-image' });
    } catch (e1) {
      return await new Promise(function (resolve, reject) {
        var url = URL.createObjectURL(file);
        var img = new Image();
        img.onload = function () { URL.revokeObjectURL(url); resolve(img); };
        img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('image')); };
        img.src = url;
      });
    }
  })();
}

/* Scales the longest side to 1568 px (the size Claude reads best) and returns a JPEG as blob and base64. */
function prepareImage(file) {
  return (async function () {
    var bmp = await loadBitmap(file);
    var w = bmp.width || bmp.naturalWidth, h = bmp.height || bmp.naturalHeight;
    var sc = Math.min(1, 1568 / Math.max(w, h));
    var cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(w * sc));
    cv.height = Math.max(1, Math.round(h * sc));
    cv.getContext('2d').drawImage(bmp, 0, 0, cv.width, cv.height);
    var blob = await new Promise(function (res) { cv.toBlob(res, 'image/jpeg', 0.9); });
    if (!blob) throw new Error('image');
    var b64 = await new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1]); };
      r.onerror = function () { rej(new Error('image')); };
      r.readAsDataURL(blob);
    });
    return { blob: blob, b64: b64 };
  })();
}

function setThumb(blob) {
  var img = $('#thumb');
  if (img.dataset.url) URL.revokeObjectURL(img.dataset.url);
  var url = URL.createObjectURL(blob);
  img.dataset.url = url;
  img.src = url;
  img.hidden = false;
}

function parseRows(data) {
  var rowsIn = Array.isArray(data) ? [data] : (data && Array.isArray(data.rows) ? data.rows : []);
  var rows = [];
  rowsIn.forEach(function (r) {
    if (!Array.isArray(r)) return;
    var row = [];
    r.forEach(function (x) {
      if (!x || typeof x !== 'object') return;
      if (x.fake === true) { row.push(mkFake({ unsure: !!x.unsure })); return; }
      var c = String(x.color || '').toLowerCase();
      var n = Math.round(Number(x.n));
      if (COLOR_INDEX[c] !== undefined && n >= 1 && n <= 13) row.push(mkTile(c, n, { unsure: !!x.unsure }));
    });
    if (row.length) rows.push(row);
  });
  return rows;
}

function extractJson(text) {
  try { return JSON.parse(text); } catch (e) {}
  var fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence) { try { return JSON.parse(fence[1]); } catch (e) {} }
  var a = text.indexOf('{'), b = text.lastIndexOf('}');
  if (a >= 0 && b > a) { try { return JSON.parse(text.slice(a, b + 1)); } catch (e) {} }
  throw { code: 'invalid_json' };
}

async function callClaude(b64, signal) {
  var res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    signal: signal,
    headers: {
      'content-type': 'application/json',
      'x-api-key': cfg.key,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify({
      model: cfg.precise ? cfg.modelPrecise : cfg.model,
      max_tokens: 2000,
      messages: [{
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: b64 } },
          { type: 'text', text: PROMPT }
        ]
      }]
    })
  });
  if (!res.ok) {
    var body = null;
    try { body = await res.json(); } catch (e) {}
    throw { status: res.status, message: body && body.error && body.error.message ? body.error.message : '' };
  }
  var data = await res.json();
  var text = (data.content || []).filter(function (b) { return b.type === 'text'; }).map(function (b) { return b.text; }).join('');
  return extractJson(text);
}

function startTimer() {
  state.elapsed = 0;
  clearInterval(timer);
  timer = setInterval(function () { state.elapsed++; if (state.reading) renderInput(); }, 1000);
}

async function readPhoto(file) {
  if (state.reading) return;
  if (!cfg.key) { openSettings(); return; }
  if (file) {
    try {
      var prep = await prepareImage(file);
      state.lastB64 = prep.b64;
      setThumb(prep.blob);
    } catch (e) {
      state.message = { kind: 'error', text: errorCopy({ code: 'image' }) };
      renderInput(); return;
    }
  }
  if (!state.lastB64) return;
  state.reading = true; state.message = null; startTimer(); renderInput();
  var ctl = new AbortController();
  state.ctl = ctl;
  var timedOut = false;
  var to = setTimeout(function () { timedOut = true; ctl.abort(); }, 120000);
  try {
    var data = await callClaude(state.lastB64, ctl.signal);
    var rows = parseRows(data);
    if (!rows.length) {
      state.message = { kind: 'error', text: (data && typeof data.note === 'string' && data.note ? esc(data.note) + ' ' : '') + 'Es wurden keine Steine erkannt. Mach ein schärferes Foto von oben.' };
    } else {
      state.rows = rows; state.example = false;
      var all = allTiles();
      var unsure = all.filter(function (t) { return t.unsure; }).length;
      var txt = '<b>' + all.length + ' Steine erkannt.</b> ' + (unsure ? unsure + ' unsicher, orange markiert. Tippe sie an und prüfe sie.' : 'Prüfe das Blatt unten kurz gegen dein Foto.');
      if (data && typeof data.note === 'string' && data.note.trim()) txt += ' ' + esc(data.note);
      state.message = { kind: 'info', text: txt };
    }
  } catch (e) {
    if (timedOut) state.message = { kind: 'error', text: errorCopy({ code: 'timeout' }) };
    else if (!(e && e.name === 'AbortError')) state.message = { kind: 'error', text: errorCopy(e) };
  } finally {
    clearTimeout(to);
    state.reading = false; state.ctl = null; clearInterval(timer);
    renderAll();
    if (!state.example) { try { $('#result').scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e2) {} }
  }
}

/* ---------- settings ---------- */
var settingsOpen = false;
function openSettings() { settingsOpen = true; renderSettings(); }
function closeSettings() { settingsOpen = false; renderSettings(); renderInput(); }
function renderSettings() {
  var host = $('#settings');
  if (!settingsOpen) { host.hidden = true; host.innerHTML = ''; return; }
  var masked = cfg.key ? 'Gespeichert, endet auf …' + esc(cfg.key.slice(-4)) : 'Noch kein Schlüssel gespeichert.';
  host.innerHTML = '<div class="sheet-panel" role="dialog" aria-modal="true" aria-label="Einstellungen">' +
    '<div><h3>Einstellungen</h3><p>Claude liest deine Fotos über deinen eigenen Anthropic-Zugang.</p></div>' +
    '<div class="field"><label for="keyInput">API-Schlüssel</label>' +
    '<input id="keyInput" type="password" autocomplete="off" autocapitalize="none" autocorrect="off" spellcheck="false" placeholder="sk-ant-…">' +
    '<p class="hint" id="keyState">' + masked + '</p></div>' +
    '<p class="hint">Der Schlüssel bleibt auf diesem Gerät und wird nur an api.anthropic.com gesendet. Erstelle in der <a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noopener">Anthropic Console</a> einen eigenen Schlüssel für diese App und setze dort ein Ausgabenlimit. Jedes Foto kostet etwas Guthaben, im Modus Genauer lesen mehr.</p>' +
    '<details><summary>Erweitert</summary>' +
    '<div class="field"><label for="modelInput">Modell normal</label><input id="modelInput" type="text" autocapitalize="none" autocorrect="off" spellcheck="false"></div>' +
    '<div class="field"><label for="modelPreciseInput">Modell genau</label><input id="modelPreciseInput" type="text" autocapitalize="none" autocorrect="off" spellcheck="false"></div>' +
    '</details>' +
    '<div class="btn-row"><button type="button" class="btn primary" id="saveCfg">Speichern</button>' +
    (cfg.key ? '<button type="button" class="btn danger" id="delKey">Schlüssel löschen</button>' : '') +
    '<button type="button" class="btn" id="closeCfg">Schließen</button></div></div>';
  $('#modelInput').value = cfg.model;
  $('#modelPreciseInput').value = cfg.modelPrecise;
  host.hidden = false;
  $('#keyInput').focus({ preventScroll: true });
}
$('#settings').addEventListener('click', function (e) {
  if (e.target === $('#settings')) { closeSettings(); return; }
  var id = e.target.id;
  if (id === 'closeCfg') closeSettings();
  else if (id === 'delKey') { cfg.key = ''; saveCfg(); renderSettings(); renderInput(); }
  else if (id === 'saveCfg') {
    var k = $('#keyInput').value.trim();
    if (k && !/^sk-ant-/.test(k)) { $('#keyState').textContent = 'Das sieht nicht wie ein Anthropic-Schlüssel aus. Er beginnt mit sk-ant-.'; return; }
    if (k) cfg.key = k;
    cfg.model = $('#modelInput').value.trim() || DEFAULT_CFG.model;
    cfg.modelPrecise = $('#modelPreciseInput').value.trim() || DEFAULT_CFG.modelPrecise;
    saveCfg();
    state.message = null;
    closeSettings();
  }
});
$('#gearBtn').addEventListener('click', openSettings);
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && settingsOpen) closeSettings(); });

/* ---------- wiring ---------- */
$('#precise').checked = !!cfg.precise;
$('#precise').addEventListener('change', function (e) { cfg.precise = e.target.checked; saveCfg(); });
$('#file').addEventListener('change', function (e) {
  var f = e.target.files && e.target.files[0];
  e.target.value = '';
  if (f) readPhoto(f);
});
$('#pickLabel').addEventListener('click', function (e) { if (!cfg.key) { e.preventDefault(); openSettings(); } });
$('#reread').addEventListener('click', function () { readPhoto(null); });
$('#pickLabel').addEventListener('keydown', function (e) {
  if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (!cfg.key) openSettings(); else $('#file').click(); }
});
var drop = $('#drop');
['dragenter', 'dragover'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('over'); }); });
['dragleave', 'drop'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('over'); }); });
drop.addEventListener('drop', function (e) {
  var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (f && /^image\//.test(f.type)) readPhoto(f);
});

/* ---------- boot ---------- */
var saved = store('okey-hand');
if (saved && Array.isArray(saved.rows)) {
  state.rows = saved.rows; state.indicator = saved.indicator || null; state.example = !!saved.example;
  uid = allTiles().reduce(function (m, t) { return Math.max(m, t.id || 0); }, 0);
} else loadExample();
renderAll();
